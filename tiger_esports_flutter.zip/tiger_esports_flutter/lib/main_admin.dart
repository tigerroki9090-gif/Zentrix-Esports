import 'app.dart';

/// Entry point for the ZENTRIX ADMIN app.
/// Build with:  flutter build apk --release -t lib/main_admin.dart
Future<void> main() async {
  await bootstrapZentrixApp(
    appTitle: 'ZENTRIX ADMIN',
    assetPath: 'assets/webapp/admin.html',
  );
}
