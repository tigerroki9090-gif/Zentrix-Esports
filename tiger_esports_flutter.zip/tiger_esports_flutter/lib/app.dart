import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'notification_service.dart';

/// Shared startup logic for both ZENTRIX ESPORTS (user) and ZENTRIX ADMIN.
/// Each entry point (main_user.dart / main_admin.dart) just calls this with
/// its own title + which legacy HTML file to load.
Future<void> bootstrapZentrixApp({
  required String appTitle,
  required String assetPath,
}) async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    // options: DefaultFirebaseOptions.currentPlatform, // uncomment after flutterfire configure
  );

  FirebaseMessaging.onBackgroundMessage(firebaseBackgroundMessageHandler);
  await NotificationService.instance.init();

  runApp(ZentrixApp(appTitle: appTitle, assetPath: assetPath));
}

class ZentrixApp extends StatelessWidget {
  const ZentrixApp({super.key, required this.appTitle, required this.assetPath});
  final String appTitle;
  final String assetPath;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: appTitle,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, brightness: Brightness.dark),
      home: LegacyWebViewScreen(assetPath: assetPath),
    );
  }
}

/// Loads the existing HTML/JS/Firebase core UNCHANGED (only the
/// firebaseConfig credentials were swapped to the new ZENTRIX project —
/// no app logic was touched) inside a WebView.
class LegacyWebViewScreen extends StatefulWidget {
  const LegacyWebViewScreen({super.key, required this.assetPath});
  final String assetPath;

  @override
  State<LegacyWebViewScreen> createState() => _LegacyWebViewScreenState();
}

class _LegacyWebViewScreenState extends State<LegacyWebViewScreen> {
  late final WebViewController _controller;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0B0F19))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) => setState(() => _loading = false),
        ),
      )
      ..loadFlutterAsset(widget.assetPath);
  }

  Future<bool> _onWillPop() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await _onWillPop()) {
          if (context.mounted) Navigator.of(context).maybePop();
        }
      },
      child: Scaffold(
        body: SafeArea(
          child: Stack(
            children: [
              WebViewWidget(controller: _controller),
              if (_loading) const Center(child: CircularProgressIndicator()),
            ],
          ),
        ),
      ),
    );
  }
}
