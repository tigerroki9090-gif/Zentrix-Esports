import 'app.dart';

/// Default entry point — identical to main_user.dart, kept so a plain
/// `flutter run` (no -t flag) still works and launches ZENTRIX ESPORTS.
Future<void> main() async {
  await bootstrapZentrixApp(
    appTitle: 'ZENTRIX ESPORTS',
    assetPath: 'assets/webapp/user.html',
  );
}
