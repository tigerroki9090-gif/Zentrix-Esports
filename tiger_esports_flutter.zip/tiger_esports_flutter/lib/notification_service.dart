import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// Must be a TOP-LEVEL (or static) function — Firebase calls this in a
/// separate isolate when a data/notification message arrives while the app
/// is fully killed or backgrounded.
@pragma('vm:entry-point')
Future<void> firebaseBackgroundMessageHandler(RemoteMessage message) async {
  // No UI work here. If the payload only has "data" (no "notification"
  // block), show a local notification manually so it's visible even when
  // the app is killed:
  await NotificationService.instance.showLocalNotification(message);
}

/// Wraps FCM + flutter_local_notifications so the legacy web app never has
/// to know notifications exist. Nothing here touches the HTML/JS layer.
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  static const _androidChannel = AndroidNotificationChannel(
    'high_importance_channel', // must match the channel id used below
    'Tournament & wallet alerts',
    description: 'Match reminders, results, wallet and withdrawal updates',
    importance: Importance.high,
  );

  Future<void> init() async {
    // 1. Ask the user for permission (Android 13+ requires this explicitly)
    await _fcm.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    // 2. Local notifications setup (used to render FCM messages that arrive
    //    while the app is in the foreground, since FCM does not auto-show
    //    a system notification in that case).
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);
    await _localNotifications.initialize(initSettings);

    await _localNotifications
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(_androidChannel);

    // 3. Foreground messages: FCM delivers these silently, so show them
    //    ourselves via flutter_local_notifications.
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      showLocalNotification(message);
    });

    // 4. Background/terminated messages are handled by the top-level
    //    handler registered in main() via FirebaseMessaging.onBackgroundMessage.

    // 5. Log the device token so you can send a test push from the Firebase
    //    console (Cloud Messaging > send test message > paste token).
    final token = await _fcm.getToken();
    if (kDebugMode) {
      debugPrint('FCM device token: $token');
    }
  }

  Future<void> showLocalNotification(RemoteMessage message) async {
    final notification = message.notification;
    final title = notification?.title ?? message.data['title'] ?? 'ZENTRIX';
    final body = notification?.body ?? message.data['body'] ?? '';

    await _localNotifications.show(
      message.hashCode,
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'high_importance_channel',
          'Tournament & wallet alerts',
          channelDescription:
              'Match reminders, results, wallet and withdrawal updates',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
    );
  }
}
