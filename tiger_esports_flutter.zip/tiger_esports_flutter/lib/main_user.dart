import 'app.dart';

/// Entry point for the ZENTRIX ESPORTS (player-facing) app.
/// Build with:  flutter build apk --release -t lib/main_user.dart
Future<void> main() async {
  await bootstrapZentrixApp(
    appTitle: 'ZENTRIX ESPORTS',
    assetPath: 'assets/webapp/user.html',
  );
}
