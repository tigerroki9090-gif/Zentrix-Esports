# ZENTRIX ESPORTS / ZENTRIX ADMIN — Flutter WebView Wrapper

One codebase, two APKs:
- **ZENTRIX ESPORTS** — loads `assets/webapp/user.html` (entry: `lib/main_user.dart`)
- **ZENTRIX ADMIN** — loads `assets/webapp/admin.html` (entry: `lib/main_admin.dart`)

Both share the same WebView wrapper and notification code (`lib/app.dart`,
`lib/notification_service.dart`). The legacy HTML/JS logic itself is
untouched — the **only** edit made to the three HTML files was swapping the
`firebaseConfig` credentials to your new project (`zentrix-esports-f90f0`),
since `user.html` previously pointed at a different, broken project. No
business logic was changed.

## Still needed from you: the logo

I couldn't download the postimg.cc image from this sandbox (no internet
access here). Before building:
1. Save the logo from `https://i.postimg.cc/WzQf5sLh/file-000000008ca88211b32a9e6f4bf6cf73.png`
2. Put it at `assets/icon/app_icon.png` in this project (ideally 1024x1024 PNG)
3. After `flutter pub get`, run:
   ```bash
   flutter pub run flutter_launcher_icons
   ```
   This generates the Android launcher icons from that file. Run it again
   any time you swap the logo. If you want *different* icons for the user
   vs admin app, generate once per icon, then manually copy the resulting
   `android/app/src/main/res/mipmap-*` folders into separate flavor source
   sets — say the word if you want that set up.

## Setup steps

1. **Scaffold native platform folders:**
   ```bash
   flutter create --org com.zentrixesports --project-name zentrix_app .
   ```
   Run inside the unzipped project folder — adds `android/`, `ios/`, etc.
   without touching your existing files.

2. **Connect the new Firebase project:**
   ```bash
   dart pub global activate flutterfire_cli
   flutterfire configure --project=zentrix-esports-f90f0
   ```
   Register two Android apps if you want separate listings/push targets —
   e.g. `com.zentrixesports.user` and `com.zentrixesports.admin` — or reuse
   one app id for both if that's simpler for now.

3. **AndroidManifest.xml** (`android/app/src/main/AndroidManifest.xml`) —
   inside `<manifest>`:
   ```xml
   <uses-permission android:name="android.permission.INTERNET"/>
   <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
   ```
   inside `<application>`:
   ```xml
   <meta-data
       android:name="com.google.firebase.messaging.default_notification_channel_id"
       android:value="high_importance_channel" />
   ```
   Set `android:label` here to whichever app this manifest belongs to
   ("ZENTRIX ESPORTS" or "ZENTRIX ADMIN") — or use build flavors if you want
   one repo to produce both with different labels/ids automatically (ask
   me and I'll wire up the flavor config).

4. **Install deps, generate icons, build:**
   ```bash
   flutter pub get
   flutter pub run flutter_launcher_icons
   flutter build apk --release -t lib/main_user.dart    # ZENTRIX ESPORTS
   flutter build apk --release -t lib/main_admin.dart   # ZENTRIX ADMIN
   ```
   Each `-t` (target) produces a separate APK in
   `build/app/outputs/flutter-apk/`. Rename them after build so they don't
   overwrite each other, or set up flavors for automatically distinct
   output names.

## Building from a phone only (Codemagic)

Same as discussed before — push this repo to GitHub from your phone,
connect it in Codemagic, and run the two build commands above as separate
build steps (or two Codemagic workflows, one per `-t` target). I can write
the `codemagic.yaml` for both APKs in one go if you want it — just confirm
and I'll add it.

## Testing push notifications

Install either APK, open it once (grants POST_NOTIFICATIONS on Android 13+),
check `flutter logs` for `FCM device token: ...`, then Firebase Console ->
Cloud Messaging -> "Send test message" -> paste the token.

## Support contact number

Good news — no code change was needed here. `user.html` already has
`9635283492` hardcoded as the **default `supportContact`** (used for the
WhatsApp "Contact Us" button when nothing is set in the database yet):

```js
supportContact: '9635283492', // FIX (Contact Info Update)
```
and again as the fallback in `handleContactUs()`. The *live* number your
users actually see is controlled from the Admin panel -> App Settings ->
"Contact Us Number (for WhatsApp)" field, which overrides this default via
the Firebase `/settings` node. So: once you (or ZENTRIX ADMIN) save
`9635283492` there, that's the number that's used — the code default just
matches it already as a safety net.

(Separately, `9848988740` appears as the default **Phone Pay / UPI ID** for
recharges — that's a different field, a payment number rather than a
contact number, so I left it as-is. Say the word if that should also
change.)

## Package ID

Using one applicationId for both APKs, as you confirmed — e.g.
`com.zentrixesports.app` for both `main_user.dart` and `main_admin.dart`
builds. One thing worth knowing: **Android identifies apps by package ID**,
so if the same person ever needs both ZENTRIX ESPORTS and ZENTRIX ADMIN
installed on the *same phone*, installing the second one will overwrite/
replace the first (they can't coexist). That's fine if these are meant for
different people/devices (players vs. admins); if any single device needs
both at once, ping me and I'll switch you to two separate IDs instead.
